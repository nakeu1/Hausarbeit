$(Document).ready(function() {
    //open modal
    $('#open_modal').click(function() {
        $('#modal_to_open').css({

            'display': 'block'
        });
    });
    // close modal
    $('#close_modal').click(function() {
        $('#modal_to_open').css({
            'display': 'none'
        })
    });

    var content = {
            "about": [{
                    "content": "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet clita kasd gubergren, no sea takimata sanctus est Lorem ipsum dolor sit amet."
                },
                {
                    "content": "Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia"
                },
                {
                    "content": "sit voluptatem accusantium doloremque laudantium, totam rem aperiam,  It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock"
                }
            ]
        }
        // utilisation du DOM API pour manipuler le website. interaction
    function loadData() {

        content.about.forEach(function(data, index) {

            var temp = index + 1;
            var id = '#about' + temp;
            document.querySelector(id).innerHTML = data.content
        })
    }

    loadData();
});